@include('public.components.header')
@yield('content')
@include('public.components.footer')