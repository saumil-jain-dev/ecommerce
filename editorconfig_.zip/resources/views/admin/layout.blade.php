@include('admin/components/header')
@include('admin/components/sidebar')
@yield('content')
@include('admin/components/footer')