<span><b>Product : </b> {{$review->product_name}}</span><br>
<span><b>User : </b> {{$review->name}}</span><br><br>
<h4>{{$review->title}}</h4>
<p>{{$review->desc}}</p>