<?php $__env->startSection('title', site_settings()->site_title); ?>
<?php $__env->startSection('content'); ?>

    <!-- Hero slider -->
    <section class="section-hero padding-b-100 next">
        <div class="cr-slider swiper-container">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->status == '1'): ?>
                        <div class="swiper-slide">
                            <div class="cr-hero-banner ">
                                <img class="cr-banner-image" src="<?php echo e(asset('public/banner/' . $item->banner_img)); ?>"
                                    alt="Banner Image">
                                <div class="container">

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="cr-left-side-contain slider-animation">

                                                <h5><span>100%</span> Organic Fruits</h5>
                                                <h1>Explore fresh & juicy fruits.</h1>
                                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet reiciendis
                                                    beatae consequuntur.</p>
                                                <div class="cr-last-buttons">
                                                    <a href="<?php echo e(url($item->pagelink)); ?>" class="cr-button">
                                                        shop now
                                                    </a>
                                                    <a href="" target="_blank">

                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </section>
    <!------/BANNER------>
    <section class="section-products padding-t-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php if($today_deal_products->isNotEmpty()): ?>
                        <!------ Today Deal PRODUCTS ------>

                        
                        <div class="row">
                            <?php $__currentLoopData = $today_deal_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6 col-6 cr-product-box mb-24 aos-init aos-animate"
                                    data-aos="fade-up" data-aos-duration="2000" data-aos-delay="300">
                                    <?php echo $__env->make('public.product-grid', $item, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                </div>
            </div>
        </div>
    </section>
    <section class="section-products padding-t-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="mb-30 aos-init aos-animate" data-aos="fade-up" data-aos-duration="2000"
                        data-aos-delay="400">
                        <div class="cr-banner">
                            <h2>Style 2</h2>
                        </div>
                        <div class="cr-banner-sub-title">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt
                                ut labore lacus vel facilisis. </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($today_deal_products->isNotEmpty()): ?>
                <div class="row mb-minus-24">
                    <?php $__currentLoopData = $today_deal_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-6 cr-product-box mb-24 aos-init aos-animate" data-aos="fade-up"
                            data-aos-duration="2000" data-aos-delay="300">
                            <?php echo $__env->make('public.product-grid', $item, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <!------/Today Deal PRODUCTS------>
    <?php endif; ?>
    </section>
    <!------ LATEST PRODUCTS ------>
    
    <!------/LATEST PRODUCTS------>
    
    <!------/BANNER GROUP------>

    <!------ FLASH SALE PRODUCTS ------>
    
    <!------/FLASH SALE PRODUCTS------>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageJsScripts'); ?>
    
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\script\resources\views/public/index.blade.php ENDPATH**/ ?>