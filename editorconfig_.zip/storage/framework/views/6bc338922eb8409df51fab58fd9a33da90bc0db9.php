<div class="cr-product-csc cr-product-card">
    <div class="cr-product-image">
        <div class="cr-image-inner">
            
            <img src="<?php echo e(asset('public/products/' . $item->thumbnail_img)); ?>" alt="product-3">


            <div class="cr-side-view">
                <?php if(Session::has('user_id')): ?>
                    <a href="javascript:void(0)" class="wishlist" data-tip="Add to Wishlist"
                        data-id="<?php echo e($item->id); ?>">
                        <i class="ri-heart-line"></i>
                    </a>
                <?php else: ?>
                <li><a href="<?php echo e(url('user_login')); ?>" data-tip="Add to Wishlist" data-id="<?php echo e($item->id); ?>"><i
                    class="far fa-heart"></i></a></li>
                    <a class="model-oraganic-product" data-bs-toggle="modal" href="#quickview" role="button">
                        <i class="ri-eye-line"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <a class="cr-shopping-bag remove-cart" href="javascript:void(0)" data-id="<?php echo e($item->id); ?>">
            <i class="ri-shopping-bag-line"></i>
        </a>
    </div>
    <div class="cr-product-details">
        <a href="<?php echo e(url('/product/' . $item->slug)); ?>" class="title"><?php echo e(substr($item->product_name, 0, 25) . '...'); ?></a>
        <p><?php echo e($item->brand_name); ?></p>
        <?php $product_rating = product_rating($item->id);  ?>
        <div class="cr-star">
            <?php $rating = 0;  ?>
            <?php if($product_rating->rating_col > 0): ?>
                <?php $rating = ceil($product_rating->rating_sum/$product_rating->rating_col);  ?>
            <?php endif; ?>
            <?php for($i = 1; $i <= 5; $i++): ?>
                <?php if($i <= $rating): ?>
                    <i class="ri-star-fill"></i>
                <?php else: ?>
                    <i class="ri-star-fill"></i>
                <?php endif; ?>
            <?php endfor; ?>

        </div>
        <?php $product_price = get_product_price($item->id); ?>
        <?php if($product_price->discount != ''): ?>
            <span class="product-discount-label">-<?php echo e($product_price->discount); ?></span>
        <?php endif; ?>
        <p class="cr-price">
            <?php if($product_price->discount != ''): ?>
                <span class="old-price"><?php echo e(site_settings()->currency); ?><?php echo e($product_price->old_price); ?></span>
        </p>
        <?php endif; ?>
        <span class="new-price"><?php echo e(site_settings()->currency); ?><?php echo e($product_price->new_price); ?></span>

    </div>
</div>

<?php /**PATH C:\xampp\htdocs\script\resources\views/public/product-grid.blade.php ENDPATH**/ ?>