<?php $__env->startSection('title', 'My Reviews'); ?>
<?php $__env->startSection('content'); ?>
    <section class="section-breadcrumb">
        <div class="cr-breadcrumb-image">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="cr-breadcrumb-title">
                            <h2>My Reviews</h2>
                            <span> <a href="<?php echo e(url('/')); ?>">Home</a> - My Reviews</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="cr-checkout-section padding-tb-100">
        <div class="container">
            <div class="row">
                <!-- Sidebar Area Start -->
                <div class=" col-lg-6 col-md-12">
                    <!-- checkout content Start -->
                    <div class="cr-checkout-content">
                        <div class="cr-checkout-inner">
                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="cr-checkout-wrap mb-30">
                                    <div class="cr-checkout-block cr-check-new">
                                        <h3 class="cr-checkout-title"><?php echo e($row->product_name); ?></h3>
                                        <div class="cr-check-block-content">
                                            <div class="cr-check-subtitle"><?php echo e($row->title); ?></div>

                                            <div class="cr-new-desc"><?php echo e($row->desc); ?>

                                            </div>
                                            <ul class="show-review-rating mb-2">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <?php if($i <= $row->rating): ?>
                                                        <i class="ri-star-fill"></i>
                                                    <?php else: ?>
                                                        <i class="ri-star-fill"></i>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            </ul>
                                            <?php if($row->hide_by_admin == '1'): ?>
                                                <div class="alert alert-danger p-2 py-0 m-0 d-inline-block">Hidden by Admin
                                                </div>
                                            <?php endif; ?>
                                            <?php if($row->approved == '0'): ?>
                                                <div class="alert alert-danger p-2 py-0 m-0 d-inline-block">Under Approval
                                                    Process</div>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!--cart content End -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wedphrwl/domains/sarthitech.com/public_html/resources/views/public/my-reviews.blade.php ENDPATH**/ ?>