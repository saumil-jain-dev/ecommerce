<?php $__env->startSection('title','User Login'); ?>
<?php $__env->startSection('content'); ?>
<section class="section-breadcrumb">
    <div class="cr-breadcrumb-image">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cr-breadcrumb-title">
                        <h2>Login</h2>
                        <span> <a href="index.html">Home</a> - Login</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section-login padding-tb-100" id="site-content">
    <div class="container">
        <div class="row d-none">
            <div class="col-lg-12">
                <div class="mb-30 aos-init aos-animate" data-aos="fade-up" data-aos-duration="2000" data-aos-delay="400">
                    <div class="cr-banner">
                        <h2>Login</h2>
                    </div>
                    <div class="cr-banner-sub-title">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                            ut labore lacus vel facilisis. </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="cr-login aos-init aos-animate" data-aos="fade-up" data-aos-duration="2000" data-aos-delay="400">
                    
                     <!-- Form Start -->
                     <?php if(Session::has('message')): ?>
                     <div class="alert alert-success" role="alert">
                     <?php echo e(Session::get('message')); ?>

                     </div>
                     <?php endif; ?>
                    <form class="cr-content-form" action="<?php echo e(URL('user_login')); ?>" method ="POST" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label>Email Address*</label>
                            <input type="email" name="username" placeholder="Enter Your Email" class="cr-form-control">
                        </div>
                        <div class="form-group">
                            <label>Password*</label>
                            <input type="password" name="password" placeholder="Enter Your password" class="cr-form-control">
                        </div>
                        <div class="remember">
                            <span class="form-group custom">
                                <input type="checkbox" id="html">
                                <label for="html">Remember Me</label>
                            </span>
                            <a class="link" href="<?php echo e(url('forgot-password')); ?>">Forgot Password?</a>

                        </div><br>
                        <div class="login-buttons">
                            <input type="submit" name="save" class="cr-button" required value="Login">
                            <a href="<?php echo e(url('signup')); ?>" class="link">
                                 Signup?
                            </a>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wedphrwl/domains/sarthitech.com/public_html/resources/views/public/user_login.blade.php ENDPATH**/ ?>