<span><b>Product : </b> <?php echo e($review->product_name); ?></span><br>
<span><b>User : </b> <?php echo e($review->name); ?></span><br><br>
<h4><?php echo e($review->title); ?></h4>
<p><?php echo e($review->desc); ?></p><?php /**PATH /home/wedphrwl/domains/sarthitech.com/public_html/resources/views/admin/reviews/view.blade.php ENDPATH**/ ?>