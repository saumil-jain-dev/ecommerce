
<?php $__env->startSection('title','Edit Review'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<?php $__env->startComponent('admin.components.content-header',['breadcrumb'=>['Dashboard'=>'admin/dashboard','All Reviews'=>'admin/reviews']]); ?>
    <?php $__env->slot('title'); ?> Edit Review <?php $__env->endSlot(); ?>
    <?php $__env->slot('add_btn'); ?>  <?php $__env->endSlot(); ?>
    <?php $__env->slot('active'); ?> Edit Review <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<!-- Main content -->
<section class="content card">
    <div class="container-fluid card-body">
        <!-- form start -->
        <form class="form-horizontal" id="update_review"  method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

            <?php if($review): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Edit Review</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="row form-group">
                                <div class="col-md-2">Product </div>
                                <div class="col-md-10"><?php echo e($review->product_name); ?></div>
                            </div>
                            <div class="row form-group">
                                <div class="col-md-2">User </div>
                                <div class="col-md-10"><?php echo e($review->name); ?></div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-2">
                                        <span>Title</span>
                                    </div>
                                    <div class="col-md-10">
                                        <input type="text" class="form-control" name="title" placeholder="Title" value="<?php echo e($review->title); ?>" required>
                                        <input type="text" class="id" value="<?php echo e($review->id); ?>" hidden>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-2">
                                        <span>Description</span>
                                    </div>
                                    <div class="col-md-10">
                                        <textarea name="desc" class="form-control" required><?php echo e($review->desc); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-md-2">Rating </div>
                                <div class="col-md-10"><?php echo e($review->rating); ?></div>
                            </div>
                            <div class="row form-group">
                                <div class="col-md-2">Status </div>
                                <div class="col-md-10">
                                    <select name="status" class="form-control">
                                        <option value="1" <?php if($review->hide_by_admin == '1'): ?> selected <?php endif; ?> >Hide</option>
                                        <option value="0" <?php if($review->hide_by_admin == '0'): ?> selected <?php endif; ?> >Show</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <?php endif; ?>
            <!-- /.row -->
            <div class="row">
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form> <!-- /.form start -->
    </div><!-- /.container-fluid -->
</section><!-- /.content -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wedphrwl/domains/sarthitech.com/public_html/resources/views/admin/reviews/edit.blade.php ENDPATH**/ ?>